//
//  main.cpp
//  Translate DAR
//
//  Created by Emily Chen on 2016-07-15.
//  Copyright © 2016 Emily C. All rights reserved.
//


#include "DAR translator.h"
using namespace std;


/* bool isWanted(const std::string & line)
 {
 return (line.find("Target Course") != string::npos);
 }
 */


bool isInterested( const string interest)
{
    string popLine;
    ifstream filePOP("/Users/emilychen/Desktop/POP.txt");
    while (getline(filePOP, popLine))
    if (popLine.find(interest) != string::npos)
    {   cout <<endl;
        return true;}
    return false;
}

int main()
{
    bool ifAnyCourseIP= false;
    ifstream myFile("/Users/emilychen/Desktop/DAR.txt");
    vector<Course> listOfCourse;
    Course sample;
    string line;
    int count = 1;
    int courseCount = 0;
    while (getline(myFile, line))
    {
        if (count % 3 == 1)
        {   listOfCourse.push_back(sample);
            listOfCourse[courseCount].addCourseLine(line);
        }
        else if (count % 3 == 2)
            listOfCourse[courseCount].addName(line);
        else
        {
            listOfCourse[courseCount].seperateCourseLine();
            courseCount ++;
        }
        count ++;

}
    
    cout << "<u> </u>"<< endl;
    double totalUnit = 0;
    for (vector<Course>::iterator it = listOfCourse.begin();it!= listOfCourse.end();it++)
    {   it -> seperateCourseLine();
        it->printOutCourse();
        totalUnit += it -> showUnit();
        if (it->showIfIP())
        {
            ifAnyCourseIP = true;
        }
    }
    
    if (ifAnyCourseIP)
        cout <<"*Courses in progress, instruct student to send in final transcript to Admission office and check DAR in fall."<<endl;
    // print out total unit
    cout << "Total Unit = ";
    cout << fixed << setprecision(1) << totalUnit << endl;
    
    //POP///////////////////////////////////////////////////
    //POP///////////////////////////////////////////////////
    //POP///////////////////////////////////////////////////
    cout << endl;
    cout << "Additional Notes: \n"<<endl;
    cout << "Referred student to Sociology department website http://www.sociology.ucla.edu\n"<< endl;
    cout << "Recommended Sociology 20, one major upper division course and one non major upper division."<<endl;
    if (isInterested("career plans"))
        cout << "Students interested in career plans and professional/graduate school, referred to Career Centre http://www.career.ucla.edu"<< endl;
        if (isInterested("community service opportunities"))
            cout << "Student expressed interests about community service, referred to Volunteer Centre and Community Service Commission http://volunteer.ucla.edu and http://www.communityservicecommission.org"<< endl;
        if (isInterested( "extracurricular activities"))
            cout << "Student expressed interests about clubs and ex-curricular activities, referred to Student Groups http://www.studentgroups.ucla.edu"<< endl;
        if (isInterested( "graduate/professional school"))
            cout << "Students interested in career plans and professional/graduate school, referred to Career Centre http://www.career.ucla.edu"<< endl;
        if (isInterested("living arrangements"))
            cout << "Student interested in housing options, referred to Community Housing Office cho.ucla.edu"<< endl;
        if (isInterested("research opportunities"))
            cout << "Student interested in research opportunities, referred to Undergraduate Research Centre - Science http://www.ugresearchsci.ucla.edu"<< endl;
        if (isInterested( "parking"))
            cout << "Student expressed interests in parking options, referred to UCLA Transportation https://main.transportation.ucla.edu"<< endl;
        if (isInterested( "music"))
            cout << "Student expressed interests in music, referred to UCLA Herb Alpert School of Music http://www.music.ucla.edu"<< endl;
        if (isInterested( "sport"))
            cout << "Student interested in sports, referred to Recreation Centre http://www.recreation.ucla.edu"<< endl;
    
    cout << endl;
    cout << "Recommended student to take three classes in the fall.\n\nAlso recommended student not to take classes with finals on the same day.\n"<< endl;
    
    return 0;
}


/*int main()
 {
 string original = "";
 string addOn = "";
 ifstream myfile;
 myfile.open("/Users/emilychen/Desktop/DAR.txt");
 while ( myfile.is_open()&&!myfile.eof())
 {
 getline(myfile, addOn);
 original += addOn;
 original += "\n";
 }
 cout << "<u>"<<seperateTheCollege(original)<< "</u>" <<endl;
 cout << original<< endl;
 return 0;
 }
 */