//
//  main.cpp
//  Translate DAR
//
//  Created by Emily Chen on 2016-07-15.
//  Copyright © 2016 Emily C. All rights reserved.
//


#include "DAR translator.h"
using namespace std;


/* bool isWanted(const std::string & line)
 {
 return (line.find("Target Course") != string::npos);
 }
 */

int main()
{
    ifstream myFile("/Users/emilychen/Desktop/DAR.txt");
    vector<Course> listOfCourse;
    Course sample;
    string line;
    int count = 1;
    int courseCount = 0;
    while (getline(myFile, line))
    {
        if (count % 3 == 1)
        {   listOfCourse.push_back(sample);
            listOfCourse[courseCount].addCourseLine(line);
        }
        else if (count % 3 == 2)
            listOfCourse[courseCount].addName(line);
        else
        {
            listOfCourse[courseCount].seperateCourseLine();
            courseCount ++;
        }
        count ++;

}
    double totalUnit = 0;
    for (vector<Course>::iterator it = listOfCourse.begin();it!= listOfCourse.end();it++)
    {   it -> seperateCourseLine();
        it->printOutCourse();
        totalUnit += it -> showUnit();
    }
    
    
    // print out total unit
    cout << "Total Unit = ";
    cout << fixed << setprecision(1) << totalUnit << endl;
    return 0;
}


/*int main()
 {
 string original = "";
 string addOn = "";
 ifstream myfile;
 myfile.open("/Users/emilychen/Desktop/DAR.txt");
 while ( myfile.is_open()&&!myfile.eof())
 {
 getline(myfile, addOn);
 original += addOn;
 original += "\n";
 }
 cout << "<u>"<<seperateTheCollege(original)<< "</u>" <<endl;
 cout << original<< endl;
 return 0;
 }
 */