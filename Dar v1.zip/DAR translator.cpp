//
//  DAR translator.cpp
//  Dar translate
//
//  Created by Emily Chen on 2016-07-28.
//  Copyright © 2016 Emily C. All rights reserved.
//

#include "DAR translator.h"

void Course::seperateCpurseLine()
{
    std::istringstream iss (courseLine);
    std::string substring;
    int count=1;
    std::vector<std::string> stringgroup;
    while (getline(iss, substring, '\t'))
    {
        if (count  == 8)
            name = substring;
        if (count == 9)
            titleName = substring;
        if (count == 10)
            addUnit(substring);
        count ++;
    }
    
}

void Course::seperateCourseLine()
{
    std::istringstream iss (courseLine);
    std::string substring;
    int count=1;
    std::vector<std::string> stringgroup;
    while (getline(iss, substring, '\t'))
    {
        if (count % 4 == 2)
            name = substring;
        
        if (count % 4 == 3)
            addUnit(substring);
        count ++;
    }
}

void Course::addCourseLine (std::string courseLine)
{
    this -> courseLine = courseLine;
}

void Course::addName (std::string name)
{
    this -> titleName = name;
}
void Course::addUnit (std::string strUnit)
{
    unit = stod(strUnit);
    
}
bool Course::ifTilteCourse()
{
    for (int i =0; i< name.size(); i++)
    {
        if (isdigit(name[i]))
        {
            if (name[i-1]=='T')
            {
                for (int k = 0; k< i-2; k++ )
                    departName += name[k];
                return true;
            }
        }
    }
    departName = "";
    return false;
}


void Course::printOutCourse()
{
    //cout << name << endl;
    if (ifTilteCourse())
    {
        std::cout << departName << " -- " << titleName << " LD (" << unit << ") "<< std::endl;
    }
    else
    {   std::cout << name << " (";
        std::cout << std::fixed << std::setprecision(1) << unit << ") " << std::endl;
    }
}

double Course::showUnit ()
{
    return unit;
}
std::string Course::seperateTheCollege (std::string& original)
{
    std::string college = "";
    //getline(original.begin(),'\n')
    for (int i= 0; original[i]!= '\n'; i++)
        college += original[i];
    original.erase(0, original.find('\n')+1);
    return college;
}
